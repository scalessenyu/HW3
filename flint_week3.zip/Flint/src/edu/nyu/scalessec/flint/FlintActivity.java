package edu.nyu.scalessec.flint;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class FlintActivity extends Activity {
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        //button1
		Button button1 = (Button)findViewById(R.id.button1);
		View.OnClickListener listener1 = new View.OnClickListener() {
			public void onClick(View v) {
				showToast("Something Cool.");
			}
		};
		button1.setOnClickListener(listener1);
		
		//button2
		final Button button2 = (Button)findViewById(R.id.button2);
		View.OnClickListener listener2 = new View.OnClickListener() {
			public void onClick(View v) {
				showToast("Something Cooler.");
			}
		};
		button2.setOnClickListener(listener2);
		
		//button3
		final Button button3 = (Button)findViewById(R.id.button3);
		View.OnClickListener listener3 = new View.OnClickListener() {
			public void onClick(View v) {
				showToast("Something COOLEST.");
			}
		};
		button3.setOnClickListener(listener3);
		
		//checkBox1
		final CheckBox checkBox = (CheckBox)findViewById(R.id.checkBox1);
		View.OnClickListener checkBoxListener = new View.OnClickListener() {
			public void onClick(View v) {
				String message = checkBox.isChecked() ? "Checked" : "Unchecked";
				showToast(message);
			}
		};
		checkBox.setOnClickListener(checkBoxListener);
		
		//toggleButton1
		final ToggleButton toggleButton = (ToggleButton)findViewById(R.id.toggleButton1);
		View.OnClickListener toggleButtonListener = new View.OnClickListener() {
			public void onClick(View v) {
				String message = toggleButton.isChecked() ? "On" : "Off";
				showToast(message);
			}
		};
		toggleButton.setOnClickListener(toggleButtonListener);
		
		//seekBar1
		SeekBar seekBar = (SeekBar)findViewById(R.id.seekBar1);
		seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            	TextView textView = (TextView)findViewById(R.id.textView1);
            	textView.setText("Value: " + Integer.toString(progress));
            }
            
            public void onStartTrackingTouch(SeekBar seekBar) {
            	//not used
            }
            
            public void onStopTrackingTouch(SeekBar seekBar) {
            	showToast("Final value: " + Integer.toString(seekBar.getProgress()));
            }
            
        });

		
    }
    
    public void showToast(String message) {
    	Toast toast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }
    
}